package ex03.di;

public interface Person {

	public boolean personShow(String name, int age, String gender);
	public boolean personShow(Person person);
}
