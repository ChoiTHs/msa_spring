package ex02.di.message;

public interface MessageService {
	
	boolean sendMessage(String msg, String rec);
}
