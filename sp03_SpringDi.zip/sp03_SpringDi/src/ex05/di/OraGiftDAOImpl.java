package ex05.di;

public class OraGiftDAOImpl implements GiftDAO {

	@Override
	public void insert(GiftVO vo) {
		System.out.println("oracle insert 발생!!!");
	}

	@Override
	public void update(int gno) {
		System.out.println("oracle update 발생!!!");
	}

}
