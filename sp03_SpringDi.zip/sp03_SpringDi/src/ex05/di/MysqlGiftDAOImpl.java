package ex05.di;

public class MysqlGiftDAOImpl implements GiftDAO {

	@Override
	public void insert(GiftVO vo) {
		System.out.println("mysql insert 발생!!!");
	}

	@Override
	public void update(int gno) {
		System.out.println("mysql update 발생!!!");
	}

}
