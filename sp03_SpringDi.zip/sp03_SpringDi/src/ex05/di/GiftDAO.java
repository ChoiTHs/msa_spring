package ex05.di;


//여러 DB들이 사용하는 공통 함수 강제 구현
public interface GiftDAO {
	void insert(GiftVO vo);
	/*
	 생길 친구들...
	 - update
	 - delete
	 - select 
	 - ...
	*/

	void update(int gno);
}
