package ex05.di;

import org.springframework.beans.factory.annotation.Autowired;

//DB 연결에 관련된 GiftDAO와 의존관계여야 한다
//주입 : setter/getter 혹은 생성자
public class GiftService {
	@Autowired//DI case 3
	private GiftDAO giftDao;
	// 자동 주입

	/*
	public GiftService(GiftDAO giftDao) {//DI case 1
		this.giftDao = giftDao;
		System.out.println("GiftService 생성자 호출");
	}

	public void setGiftDao(GiftDAO giftDao) {//DI case 2
		this.giftDao = giftDao;
	}
	*/

	public void wirte(GiftVO vo) {
		this.giftDao.insert(vo);
	}
	
	public void update(int gno) {
		this.giftDao.update(gno);
	}
}
