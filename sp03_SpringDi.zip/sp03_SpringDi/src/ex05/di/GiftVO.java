package ex05.di;

//DB테이블과 1:1 관계
public class GiftVO {
/*
 - member 필드
 - setter / getter
 - constructur
 - toString
*/
	public GiftVO() {
	}

}
