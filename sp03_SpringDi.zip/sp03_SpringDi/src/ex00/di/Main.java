package ex00.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		/*
		Mybean myB = new Mybean();
		Mybean myB2 = new Mybean("홍길동");
		Mybean myB3 = new Mybean();
		
		System.out.println(myB + " | " + myB2 + " | " + myB3);//메모리주소 다름
		System.out.println("--------------------------------");
		
		Singleton s = Singleton.getInstance();
		Singleton s2 = Singleton.getInstance();
		Singleton s3 = Singleton.getInstance();
		
		System.out.println(s + " | " + s2 + " | " + s3);//메모리주소 같음
		*/
		
//		ApplicationContext cont = new GenericXmlApplicationContext("classpath:ex00/di/appCtx.xml");
		ApplicationContext cont = new GenericXmlApplicationContext("ex00/di/appCtx.xml");
		
		Mybean m = cont.getBean("myBean",Mybean.class);
		Mybean m2 = cont.getBean("myBean",Mybean.class);
		Mybean m3 = cont.getBean("myBean",Mybean.class);
		
		Singleton s = cont.getBean("single",Singleton.class);
		Singleton s2 = cont.getBean("single",Singleton.class);
		/*
		 스피링은 싱글톤 패턴이 적용되어 있다.
		 */
		System.out.println(m);
		System.out.println(m2);
		System.out.println(m3);
		
		System.out.println(s);
		System.out.println(s2);
		
		/*
		 getBean()
		 1. 
		*/
	}
}
