package ex00.di;

public class Mybean {
	
	public Mybean() {
		System.out.println("Default");
	}

	public Mybean(String name) {
		System.out.println("overloading : " + name);
	}
}
