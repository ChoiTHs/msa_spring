package quiz;

public class Dog implements Animal {

	@Override
	public void sound() {
		System.out.println("멍멍");

	}

	@Override
	public void leg() {
		System.out.println("다리 4개");

	}

}
