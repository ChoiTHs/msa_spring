package quiz;

import org.springframework.beans.factory.annotation.Autowired;

public class MyApp {
	@Autowired
	private Animal animal;
	
	public void sound() {
		this.animal.sound();
	}
	public void leg() {
		this.animal.leg();
	}

}
