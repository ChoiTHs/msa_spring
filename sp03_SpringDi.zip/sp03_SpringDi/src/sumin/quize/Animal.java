package quiz;

public interface Animal {
	void sound();
	void leg();

}
