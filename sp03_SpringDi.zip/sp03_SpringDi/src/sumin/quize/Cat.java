package quiz;

public class Cat implements Animal {

	@Override
	public void sound() {
		System.out.println("냐옹");

	}

	@Override
	public void leg() {
		System.out.println("다리 4개");

	}

}
