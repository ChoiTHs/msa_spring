package quiz;

public class Duck implements Animal {

	@Override
	public void sound() {
		System.out.println("꽥");

	}

	@Override
	public void leg() {
		System.out.println("다리 2개");
	}

}
