package quize;

import org.springframework.beans.factory.annotation.Autowired;

public class Animals {

	@Autowired
	private Animal animal;
	
	public Animals() {}
	
	public Animals(Animal animal) {
		this.animal = animal;
	}
	
	public void sound() {
		this.animal.sounds();
	}
	public void leg() {
		this.animal.legs();
	}
}
