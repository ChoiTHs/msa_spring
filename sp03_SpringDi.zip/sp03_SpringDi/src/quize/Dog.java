package quize;

public class Dog implements Animal {
	
	String leg, sound;
	
	@Override
	public void legs() {
		System.out.println("4개");
	}

	@Override
	public void sounds() {
		System.out.println("멍");
	}

}
