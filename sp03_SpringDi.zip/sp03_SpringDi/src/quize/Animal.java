package quize;

public interface Animal {
	void legs();
	void sounds();
}
