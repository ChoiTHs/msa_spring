package ex01.di;

public interface Player {
	
	public void input();
	public void info();
}
